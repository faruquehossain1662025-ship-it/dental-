<?php
require_once '../config/config.php';

// ভিজিটর ট্র্যাক
trackVisitor();

// সেটিংস লোড
$settings = getSettings();
$banners = loadJsonData(BANNERS_FILE);
$activeBanners = array_filter($banners, fn($b) => $b['active'] ?? true);
$services = loadJsonData(SERVICES_FILE);
$activeServices = array_filter($services, fn($s) => $s['active'] ?? true);
$offers = loadJsonData(OFFERS_FILE);
$activeOffers = array_filter($offers, fn($o) => $o['active'] ?? true);
$reviews = loadJsonData(REVIEWS_FILE);
$approvedReviews = array_filter($reviews, fn($r) => $r['approved'] ?? false);
$news = loadJsonData(NEWS_FILE);
$activeNews = array_filter($news, fn($n) => $n['active'] ?? true);

// Meta tags for SEO
$pageTitle = $settings['site_name'] . ' - ' . $settings['site_description'];
$pageDescription = $settings['site_description'];
?>

<!DOCTYPE html>
<html lang="bn" dir="ltr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($pageTitle); ?></title>
    <meta name="description" content="<?php echo htmlspecialchars($pageDescription); ?>">
    
    <!-- Open Graph tags -->
    <meta property="og:title" content="<?php echo htmlspecialchars($pageTitle); ?>">
    <meta property="og:description" content="<?php echo htmlspecialchars($pageDescription); ?>">
    <meta property="og:type" content="website">
    <meta property="og:url" content="<?php echo SITE_URL; ?>">
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link href="css/style.css" rel="stylesheet">
</head>
<body>
    
    <!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/689879e722fdc61926d1b3b4/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
    
    
    
    <!-- Breaking News -->
    <?php if ($settings['breaking_news_enabled'] && !empty($activeNews)): ?>
    <div class="breaking-news bg-primary text-white py-2">
        <div class="container-fluid">
            <div class="d-flex align-items-center">
                <span class="badge bg-light text-primary me-3 fw-bold">সর্বশেষ</span>
                <div class="news-ticker overflow-hidden flex-grow-1">
                    <?php foreach ($activeNews as $newsItem): ?>
                        <span class="news-item"><?php echo htmlspecialchars($newsItem['title']); ?></span>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm sticky-top">
        <div class="container">
            <a class="navbar-brand fw-bold text-primary fs-3" href="/">
                <i class="bi bi-heart-pulse me-2"></i>
                <?php echo htmlspecialchars($settings['site_name']); ?>
            </a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="/">হোম</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="services.php">সেবাসমূহ</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="appointment.php">অ্যাপয়েন্টমেন্ট</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="reviews.php">রিভিউ</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="track.php">অ্যাপয়েন্টমেন্ট ট্র্যাক</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link btn btn-primary text-white ms-2 px-3" href="appointment.php">
                            <i class="bi bi-calendar-plus me-1"></i> বুক করুন
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Hero Slider -->
    <?php if (!empty($activeBanners)): ?>
    <div id="heroSlider" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-indicators">
            <?php foreach ($activeBanners as $index => $banner): ?>
                <button type="button" data-bs-target="#heroSlider" data-bs-slide-to="<?php echo $index; ?>" 
                        <?php echo $index === 0 ? 'class="active"' : ''; ?>></button>
            <?php endforeach; ?>
        </div>
        
        <div class="carousel-inner">
            <?php foreach ($activeBanners as $index => $banner): ?>
            <div class="carousel-item <?php echo $index === 0 ? 'active' : ''; ?>">
                <div class="hero-slide" style="background: linear-gradient(rgba(0,0,0,0.4), rgba(0,0,0,0.4)), url('<?php echo $banner['image'] ?: 'https://images.unsplash.com/photo-1559757148-5c350d0d3c56?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80'; ?>') center/cover;">
                    <div class="container text-center text-white">
                        <div class="row justify-content-center">
                            <div class="col-lg-8">
                                <h1 class="display-4 fw-bold mb-4"><?php echo htmlspecialchars($banner['title']); ?></h1>
                                <?php if (!empty($banner['subtitle'])): ?>
                                    <p class="lead mb-4"><?php echo htmlspecialchars($banner['subtitle']); ?></p>
                                <?php endif; ?>
                                <div class="d-flex gap-3 justify-content-center">
                                    <a href="appointment.php" class="btn btn-primary btn-lg px-5">
                                        <i class="bi bi-calendar-plus me-2"></i>অ্যাপয়েন্টমেন্ট বুক করুন
                                    </a>
                                    <a href="services.php" class="btn btn-outline-light btn-lg px-5">
                                        সেবা দেখুন
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        
        <button class="carousel-control-prev" type="button" data-bs-target="#heroSlider" data-bs-slide="prev">
            <span class="carousel-control-prev-icon"></span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#heroSlider" data-bs-slide="next">
            <span class="carousel-control-next-icon"></span>
        </button>
    </div>
    <?php endif; ?>

    <!-- Special Offers with Countdown -->
    <?php if (!empty($activeOffers)): ?>
    <section class="py-5 bg-gradient-primary text-white">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-8">
                    <h2 class="display-6 fw-bold mb-3">
                        <i class="bi bi-gift me-3"></i>বিশেষ অফার
                    </h2>
                    <?php foreach ($activeOffers as $offer): ?>
                    <div class="offer-card">
                        <h3 class="h4 fw-bold"><?php echo htmlspecialchars($offer['title']); ?></h3>
                        <p class="mb-3"><?php echo htmlspecialchars($offer['description']); ?></p>
                        <div class="d-flex align-items-center gap-3">
                            <span class="badge bg-warning text-dark fs-5 px-3 py-2">
                                <?php echo htmlspecialchars($offer['discount']); ?> ছাড়
                            </span>
                            <a href="appointment.php" class="btn btn-light text-primary fw-bold">
                                এখনই বুক করুন
                            </a>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <div class="col-lg-4">
                    <div class="countdown-timer text-center p-4 rounded">
                        <h4 class="mb-3">অফার শেষ হতে বাকি:</h4>
                        <div id="countdown" class="d-flex justify-content-center gap-3">
                            <div class="time-unit">
                                <div class="time-value fs-2 fw-bold" id="days">00</div>
                                <div class="time-label">দিন</div>
                            </div>
                            <div class="time-unit">
                                <div class="time-value fs-2 fw-bold" id="hours">00</div>
                                <div class="time-label">ঘণ্টা</div>
                            </div>
                            <div class="time-unit">
                                <div class="time-value fs-2 fw-bold" id="minutes">00</div>
                                <div class="time-label">মিনিট</div>
                            </div>
                            <div class="time-unit">
                                <div class="time-value fs-2 fw-bold" id="seconds">00</div>
                                <div class="time-label">সেকেন্ড</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <!-- Services Section -->
    <section class="py-5">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="display-5 fw-bold text-primary mb-3">আমাদের সেবাসমূহ</h2>
                <p class="lead text-muted">আধুনিক যন্ত্রপাতি ও অভিজ্ঞ ডাক্তারের মাধ্যমে সর্বোচ্চ মানের সেবা</p>
            </div>
            
            <div class="row g-4">
                <?php foreach (array_slice($activeServices, 0, 6) as $service): ?>
                <div class="col-lg-4 col-md-6">
                    <div class="service-card card h-100 border-0 shadow-sm">
                        <div class="card-body text-center p-4">
                            <div class="service-icon mb-3">
                                <i class="bi bi-heart-pulse text-primary" style="font-size: 3rem;"></i>
                            </div>
                            <h4 class="card-title mb-3"><?php echo htmlspecialchars($service['name']); ?></h4>
                            <p class="card-text text-muted mb-3"><?php echo htmlspecialchars($service['description']); ?></p>
                            <div class="d-flex justify-content-between align-items-center">
                                <span class="text-primary fw-bold fs-5"><?php echo htmlspecialchars($service['price']); ?></span>
                                <span class="text-muted small"><?php echo htmlspecialchars($service['duration']); ?></span>
                            </div>
                            <a href="appointment.php?service=<?php echo urlencode($service['name']); ?>" class="btn btn-primary mt-3">
                                অ্যাপয়েন্টমেন্ট নিন
                            </a>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            
            <div class="text-center mt-5">
                <a href="services.php" class="btn btn-outline-primary btn-lg">
                    সকল সেবা দেখুন <i class="bi bi-arrow-right ms-2"></i>
                </a>
            </div>
        </div>
    </section>

    <!-- Reviews Section -->
    <?php if (!empty($approvedReviews)): ?>
    <section class="py-5 bg-light">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="display-5 fw-bold text-primary mb-3">রোগীদের মতামত</h2>
                <p class="lead text-muted">আমাদের সেবা নিয়ে রোগীরা কী বলছেন</p>
            </div>
            
            <div class="row g-4">
                <?php foreach (array_slice($approvedReviews, 0, 3) as $review): ?>
                <div class="col-lg-4">
                    <div class="review-card card border-0 shadow-sm h-100">
                        <div class="card-body p-4">
                            <div class="d-flex mb-3">
                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                    <i class="bi bi-star<?php echo $i <= ($review['rating'] ?? 0) ? '-fill text-warning' : ' text-muted'; ?>"></i>
                                <?php endfor; ?>
                            </div>
                            <p class="card-text"><?php echo htmlspecialchars($review['comment']); ?></p>
                            <div class="d-flex align-items-center mt-3">
                                <div class="avatar-circle me-3">
                                    <?php echo strtoupper(substr($review['name'], 0, 1)); ?>
                                </div>
                                <div>
                                    <h6 class="mb-0"><?php echo htmlspecialchars($review['name']); ?></h6>
                                    <small class="text-muted"><?php echo htmlspecialchars($review['service']); ?></small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            
            <div class="text-center mt-5">
                <a href="reviews.php" class="btn btn-outline-primary btn-lg">
                    সকল রিভিউ দেখুন <i class="bi bi-arrow-right ms-2"></i>
                </a>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <!-- Contact & Location -->
    <section class="py-5 bg-primary text-white">
        <div class="container">
            <div class="row g-4">
                <div class="col-lg-6">
                    <h3 class="fw-bold mb-4">যোগাযোগ করুন</h3>
                    <div class="contact-info">
                        <div class="d-flex align-items-center mb-3">
                            <i class="bi bi-telephone-fill me-3 fs-4"></i>
                            <div>
                                <h6 class="mb-0">ফোন নম্বর</h6>
                                <a href="tel:<?php echo $settings['contact_phone']; ?>" class="text-white text-decoration-none">
                                    <?php echo htmlspecialchars($settings['contact_phone']); ?>
                                </a>
                            </div>
                        </div>
                        <div class="d-flex align-items-center mb-3">
                            <i class="bi bi-envelope-fill me-3 fs-4"></i>
                            <div>
                                <h6 class="mb-0">ইমেইল</h6>
                                <a href="mailto:<?php echo $settings['contact_email']; ?>" class="text-white text-decoration-none">
                                    <?php echo htmlspecialchars($settings['contact_email']); ?>
                                </a>
                            </div>
                        </div>
                        <div class="d-flex align-items-center mb-3">
                            <i class="bi bi-geo-alt-fill me-3 fs-4"></i>
                            <div>
                                <h6 class="mb-0">ঠিকানা</h6>
                                <p class="mb-0"><?php echo htmlspecialchars($settings['address']); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <h3 class="fw-bold mb-4">দ্রুত অ্যাপয়েন্টমেন্ট</h3>
                    <form id="quickAppointmentForm" class="needs-validation" novalidate>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <input type="text" class="form-control" name="name" placeholder="আপনার নাম" required>
                            </div>
                            <div class="col-md-6">
                                <input type="tel" class="form-control" name="phone" placeholder="ফোন নম্বর" required>
                            </div>
                            <div class="col-12">
                                <select class="form-select" name="service" required>
                                    <option value="">সেবা নির্বাচন করুন</option>
                                    <?php foreach ($activeServices as $service): ?>
                                        <option value="<?php echo htmlspecialchars($service['name']); ?>">
                                            <?php echo htmlspecialchars($service['name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-12">
                                <button type="submit" class="btn btn-light text-primary fw-bold w-100">
                                    <i class="bi bi-calendar-plus me-2"></i>অ্যাপয়েন্টমেন্ট নিন
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-dark text-white py-4">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <p class="mb-0">&copy; <?php echo date('Y'); ?> <?php echo htmlspecialchars($settings['site_name']); ?>. সকল অধিকার সংরক্ষিত।</p>
                </div>
                <div class="col-lg-6 text-lg-end">
                    <div class="social-links">
                        <a href="#" class="text-white me-3"><i class="bi bi-facebook"></i></a>
                        <a href="#" class="text-white me-3"><i class="bi bi-twitter"></i></a>
                        <a href="#" class="text-white me-3"><i class="bi bi-instagram"></i></a>
                        <a href="admin/" class="text-muted small">অ্যাডমিন</a>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <!-- Live Chat -->
    <?php if ($settings['live_chat_enabled'] && !empty($settings['tawk_to_id'])): ?>
    <script type="text/javascript">
        var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
        (function(){
            var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
            s1.async=true;
            s1.src='https://embed.tawk.to/<?php echo $settings['tawk_to_id']; ?>/default';
            s1.charset='UTF-8';
            s1.setAttribute('crossorigin','*');
            s0.parentNode.insertBefore(s1,s0);
        })();
    </script>
    <?php endif; ?>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="js/script.js"></script>
    
    <script>
        // Countdown Timer
        <?php if (!empty($activeOffers)): ?>
        const offerEndDate = new Date('<?php echo $activeOffers[0]['valid_until']; ?>').getTime();
        
        const countdown = setInterval(function() {
            const now = new Date().getTime();
            const distance = offerEndDate - now;
            
            const days = Math.floor(distance / (1000 * 60 * 60 * 24));
            const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
            const seconds = Math.floor((distance % (1000 * 60)) / 1000);
            
            document.getElementById("days").innerHTML = days.toString().padStart(2, '0');
            document.getElementById("hours").innerHTML = hours.toString().padStart(2, '0');
            document.getElementById("minutes").innerHTML = minutes.toString().padStart(2, '0');
            document.getElementById("seconds").innerHTML = seconds.toString().padStart(2, '0');
            
            if (distance < 0) {
                clearInterval(countdown);
                document.getElementById("countdown").innerHTML = "অফার শেষ!";
            }
        }, 1000);
        <?php endif; ?>
    </script>
</body>
</html>